#lang racket
;streams